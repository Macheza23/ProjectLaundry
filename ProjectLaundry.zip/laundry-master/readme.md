<img src="https://banners.beyondco.de/Laundry%20App.png?theme=light&packageManager=&packageName=&pattern=architect&style=style_1&description=Aplikasi+Management+Laundry&md=1&showWatermark=1&fontSize=100px&images=truck" />
<p>Halo, ini adalah aplikasi Laundry yang dibangun dengan cinta (love). Aplikasi ini sudah bisa multi toko loh, alias kamu bisa membuat cabang laundry.<br>


<h3><b>Cara Install</b></h3>
<p>
1. Pastikan kamu sudah menginstall tools yg diperlukan untuk menggunakan laravel, karena project ini di bangun dengan Framework      Laravel. <br>
2. Silahkan Clone dengan perintah 'Git Clone https://github.com/andes2912/laundry.git'. <br>
3. Jalankan perintah 'Composer Install' pada direktori project <br>
4. File .env sudah include, kalian hanya perlu menyesuaikan nama database<br>
5. Buat DB dan jalankan perintah 'php artisan migrate --seed'<br>
6. Login dengan 'admin@laundry.com' & password '123456' <br>

Note : Aplikasi ini akan terus saya update.<br>
Kalau ada pertanyaan bisa kontak aku di email ini <b>andridesmana29@outlook.com</b>
</p>

## Package
- [IndoBank](https://github.com/andes2912/indobank)

## Fitur Release
- 2.1.0 [Lihat Perubahan](https://github.com/andes2912/laundry/releases/tag/2.1.0)
- 2.0.0 [Lihat Perubahan](https://github.com/andes2912/laundry/releases/tag/2.0)

</br>
## License

The Laravel framework is open-source software licensed under the [MIT license](https://opensource.org/licenses/MIT).
