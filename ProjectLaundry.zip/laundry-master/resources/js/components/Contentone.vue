<template>
  <div class="col-12" style="margin-bottom: 35% !important">
    <div class="panel panel-forum">
      <div class="justify-content-start">
        <div class="col-md-6">
          <img :src="'frontend/img/suply.png'" style="width: 100%; max-height:400px; min-height:400px" alt="">
        </div>
        <div class="col-md-6" style="max-height:400px; min-height:400px;">
        <div class="" style="margin-top: 20%">
            <h1 class="text-center" style="color: black">
              Solusi Pakaian Kotor Ingat kami !
            </h1>
            <h3 class="text-center">
              Tunggu aja dirumah, biar kurir kami yang jemput dan antar pakaian kotor kamu :)
            </h3>
        </div>
        </div>
      </div>
    </div>
  </div>
</template>